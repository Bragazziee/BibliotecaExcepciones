/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author braga
 */

// Proyecto: BibliotecaExcepciones mejorado para evaluación completa

import java.util.*;
import java.io.*;

// Clase que representa un libro en la biblioteca
class Libro {
    private String titulo;
    private String autor;
    private boolean prestado;

    public Libro(String titulo, String autor) {
        this.titulo = titulo;
        this.autor = autor;
        this.prestado = false;
    }

    public String getTitulo() { return titulo; }
    public boolean isPrestado() { return prestado; }
    public void prestar() { this.prestado = true; }
    public void devolver() { this.prestado = false; }

    public String toString() {
        return titulo + " de " + autor + (prestado ? " (Prestado)" : " (Disponible)");
    }
}

// Clase que representa un usuario de la biblioteca
class Usuario {
    private String rut;
    private String nombre;

    public Usuario(String rut, String nombre) {
        this.rut = rut;
        this.nombre = nombre;
    }

    public String getRut() { return rut; }
    public String getNombre() { return nombre; }

    public String toString() {
        return nombre + " (" + rut + ")";
    }
}

// Excepciones personalizadas
class LibroNoEncontradoException extends Exception {
    public LibroNoEncontradoException(String mensaje) { super(mensaje); }
}

class LibroYaPrestadoException extends Exception {
    public LibroYaPrestadoException(String mensaje) { super(mensaje); }
}

class UsuarioNoRegistradoException extends Exception {
    public UsuarioNoRegistradoException(String mensaje) { super(mensaje); }
}

// Clase que representa la biblioteca con usuarios
class Biblioteca {
    private ArrayList<Libro> libros;
    private HashMap<String, Usuario> usuarios;

    public Biblioteca() {
        libros = new ArrayList<>();
        usuarios = new HashMap<>();
    }

    public void agregarLibro(Libro libro) {
        libros.add(libro);
    }

    public void registrarUsuario(Usuario usuario) {
        usuarios.put(usuario.getRut(), usuario);
    }

    public void prestarLibro(String titulo, String rutUsuario)
            throws LibroNoEncontradoException, LibroYaPrestadoException, UsuarioNoRegistradoException {

        if (!usuarios.containsKey(rutUsuario)) {
            throw new UsuarioNoRegistradoException("El usuario no está registrado.");
        }

        for (Libro libro : libros) {
            if (libro.getTitulo().equalsIgnoreCase(titulo)) {
                if (libro.isPrestado()) {
                    throw new LibroYaPrestadoException("El libro ya está prestado.");
                } else {
                    libro.prestar();
                    System.out.println("Libro prestado a " + usuarios.get(rutUsuario).getNombre() + ": " + libro);
                    return;
                }
            }
        }

        throw new LibroNoEncontradoException("El libro no fue encontrado.");
    }

    public void listarLibros() {
        for (Libro libro : libros) {
            System.out.println(libro);
        }
    }

    public void listarUsuarios() {
        for (Usuario usuario : usuarios.values()) {
            System.out.println(usuario);
        }
    }
}

// Clase principal
public class BibliotecaExcepciones {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Biblioteca biblioteca = new Biblioteca();

        // Libros y usuarios iniciales
        biblioteca.agregarLibro(new Libro("1984", "George Orwell"));
        biblioteca.agregarLibro(new Libro("El Principito", "Antoine de Saint-Exupéry"));
        biblioteca.registrarUsuario(new Usuario("12345678-9", "Ana Torres"));
        biblioteca.registrarUsuario(new Usuario("98765432-1", "Luis Pérez"));

        boolean continuar = true;

        while (continuar) {
            System.out.println("\n1. Listar libros\n2. Registrar usuario\n3. Listar usuarios\n4. Prestar libro\n5. Salir");
            try {
                System.out.print("Seleccione una opcion: ");
                int opcion = scanner.nextInt();
                scanner.nextLine();

                switch (opcion) {
                    case 1:
                        biblioteca.listarLibros();
                        break;
                    case 2:
                        System.out.print("Ingrese nombre del usuario: ");
                        String nombre = scanner.nextLine();
                        System.out.print("Ingrese RUT del usuario: ");
                        String rut = scanner.nextLine();
                        biblioteca.registrarUsuario(new Usuario(rut, nombre));
                        System.out.println("Usuario registrado con exito.");
                        break;
                    case 3:
                        biblioteca.listarUsuarios();
                        break;
                    case 4:
                        System.out.print("Ingrese RUT del usuario: ");
                        String rutPrestamo = scanner.nextLine();
                        System.out.print("Ingrese el titulo del libro: ");
                        String titulo = scanner.nextLine();
                        biblioteca.prestarLibro(titulo, rutPrestamo);
                        break;
                    case 5:
                        continuar = false;
                        break;
                    default:
                        System.out.println("Opcion invalida.");
                }

            } catch (InputMismatchException e) {
                System.out.println("Error: Debes ingresar un numero entero.");
                scanner.nextLine();
            } catch (LibroNoEncontradoException | LibroYaPrestadoException | UsuarioNoRegistradoException e) {
                System.out.println("Excepcion: " + e.getMessage());
            }
        }

        System.out.println("Programa finalizado.");
    }
}
